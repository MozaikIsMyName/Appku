---
name: Feature
about: New feature idea

---

### Summary
What's the new feature about? What should it do?

### Proposal
How should it work? API ideas?

### Additional Notes
Reference links or comments 
