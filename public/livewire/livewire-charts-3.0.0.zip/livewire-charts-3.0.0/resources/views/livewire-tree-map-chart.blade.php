<div
    style="width: 100%; height: 100%;"
    x-data="{ ...livewireChartsTreeMapChart() }"
    x-init="init()"
>
    <div wire:ignore x-ref="container"></div>
</div>
